--1.	Change salary of employee 115 to 8000 if the existing salary is less than 6000. 

UPDATE employees
SET    salary = 8000
WHERE  employee_id= 115
AND salary<6000;
 select* from employees;
 
--2.	Insert a new employee into employees with all the required details. 

INSERT INTO  employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,commission_pct,manager_id,department_id)
Values 
(207,'cedric','niango','CNIANGO@','514.456.6787','23-05-19','IT_PROG',150000,0.15,148,90);


--3.	Delete department 20. 

DELETE FROM job_history
 WHERE  department_id =20;
 DELETE FROM departments
 WHERE  department_id =20;

--4.	Change job ID of employee 110 to IT_PROG if the employee belongs to department 10 and the existing job ID does not start with IT.

UPDATE employees
SET    Job_id ='IT_PROG'
WHERE  employee_id= 110
AND department_id=10
AND job_id is not LIKE '%IT%';

--5.	Insert a row into departments table with manager ID 120 and location ID in any location ID for city Tokyo.

select* from departments;
INSERT INTO  departments(department_id,department_name,manager_id,location_id)
Values 
(300,'ELECTRIC',120,1200);

-- Display department name and number of employees in the department.

SELECT d.department_name  , count(e.employee_id)
FROM Departments d
   INNER JOIN
   employees e
   ON   d.department_id=e.department_id
  GROUP BY d.department_name ; 

   
--6.	Display job title, employee ID, number of days between ending date and starting date for all jobs in department 30 from job history.
--no matchin for this display because there is no departement_id= 30 in job history

select employee_id, end_date-start_date,department_id
from job_history
where department_id=30;

--7.	Display department name and manager first name.


select department_name,manager_id
from departments;

--8.	Display department name, manager name, and city.

SELECT d.department_name  , d.manager_id, l.city
FROM Departments d
   INNER JOIN
   locations l 
   ON   d.location_id=l.location_id
   
--9.	Display country name, city, and department name.

SELECT c.country_name,l.city, d.department_name 
FROM Departments d
   INNER JOIN
   locations l
 ON d.location_id=l.location_id
 inner join 
 countries c
 on c.country_id=l.country_id;
   
--10.	Display job title, department name, employee last name, starting date for all jobs from 2000 to 2005.

SELECT j.job_title,d.department_name,e.last_name,e.hire_date
FROM jobs j
   INNER JOIN
   employees e
   ON   j.job_id=e.job_id
   INNER JOIN
   departments  d
   ON d.department_id = e.department_id
   Where hire_date between '00-01-01' and '05-12-31';
   
--11.	Display job title and average salary of employees

select j.job_title,AVG(e.salary)
from jobs j
inner join
employees e
on j.job_id=e.job_id
group by j.job_title;



--12.	Display job title, employee name, and the difference between maximum salary for the job and salary of the employee.

SELECT j.job_title,e.first_name,(j.max_salary)-(e.salary) as difference_maxsalary_salary
FROM jobs j
   INNER JOIN
   employees e
   ON   j.job_id=e.job_id;
   
--13.	Display last name, job title of employees who have commission percentage and belongs to department 30.

SELECT e.last_name,j.job_title,e.commission_pct,e.department_id
FROM employees e
   INNER JOIN
   jobs j
   ON   e.job_id=j.job_id
   where department_id=30;
   
--14.	Display details of jobs that were done by any employee who is currently drawing more than 15000 of salary.

SELECT j.job_title,e.salary
FROM employees e
   INNER JOIN
   jobs j
   ON   e.job_id=j.job_id
   where salary>15000;

--15.	Display department name, manager name, and salary of the manager for all managers whose experience is more than 5 years.
--no matching for this query 

select d.department_name,e.manager_id,e.salary,j.job_title,((h.end_date)-(h.start_date))/365 as experiences_years
from  employees e
INNER JOIN
departments d
on  d.manager_id=e.manager_id
INNER JOIN
jobs j
on  e.job_id=j.job_id
INNER JOIN
job_history h
on e.job_id=h.job_id
WHERE  job_title LIKE'%Manager%'
and ((h.end_date)-(h.start_date))/365>5;

--16.	Display employee name if the employee joined before his manager.
--not sure think missed some information about manager like start date, hire date 

select e.first_name, j.job_id,j.start_date
from employees e
inner join
job_history j
on e.job_id=j.job_id
order by j.start_date desc;


--17.	Display employee name, job title for the jobs employee did in the past where the job was done less than six months.
--no matching for this query

select e.first_name,j.job_title,((h.end_date)-(h.start_date))/30 as experiences_months
from  employees e
INNER JOIN
jobs j
on  e.job_id=j.job_id
INNER JOIN
job_history h
on e.job_id=h.job_id
where ((h.end_date)-(h.start_date))/30<6;

--18.Display employee name and country in which he is working.

select e.first_name, c.country_name
from employees e
inner join
departments d
on e.department_id=d.department_id
inner join
locations l
on d.location_id=l.location_id
inner join
countries c
on c.country_id=l.country_id;
 


--19.	Display department name, average salary and number of employees with commission within the department.

select d.department_name, avg(e.salary), e.commission_pct
from departments d
inner join 
employees e
on d.manager_id=e.manager_id
group by d.department_name,e.commission_pct
having e.commission_pct>0;



--20.	Display the month in which more than 5 employees joined in any department located in Sydney.
--no matching for this query
select e.hire_date,l.city, count(e.employee_id)
from employees e
inner join
departments d
on e.department_id=d.department_id
inner join
locations l
on l.location_id=d.location_id
group by e.hire_date,l.city
having l.city='Sidney' and count(e.employee_id)>=5;

--Display details of departments in which the maximum salary is more than 10000.

select d.department_name,j.max_salary
from departments d
inner join 
employees e
on d.department_id=e.department_id
inner join
jobs j
on j.job_id=e.job_id
where j.max_salary>10000;

--21.	Display details of departments managed by �Smith�.
--no matching there is no column name of manager smith 

select last_name,department_id, manager_id
from employees
where last_name= 'Smith';

--22.	Display jobs into which employees joined in the current year.

select job_id, hire_date
from employees
WHERE  hire_date BETWEEN '23-01-01' AND  '23-12-31';

--23.	Display employees who did not do any job in the past.

select j.employee_id,count(j.department_id)
from job_history j
group by  j.employee_id
having count(j.department_id)=1;

--24.	Display job title and average salary for employees who did a job in the past.

select  j.job_title, count(h.employee_id),avg(e.salary)
from jobs j
inner join
employees e
on j.job_id=e.job_id
inner join
job_history h
on h.job_id=j.job_id
group by  j.job_title;

--25.	Display country name, city, and number of departments where department has more than 5 employees.

select c.country_name, l.city, (d.department_name), count(e.employee_id)
from countries c
inner join
locations l
on c.country_id=l.country_id
inner join
departments d
on d.location_id=l.location_id
inner join
employees e
on e.manager_id=d.manager_id
group by c.country_name, l.city, (d.department_name)
having count(e.employee_id)>5;

--26.	Display details of manager who manages more than 5 employees.

select manager_id,count(employee_id)
from employees
group by manager_id
having count(employee_id)>5;

--27.	Display employee name, job title, start date, and end date of past jobs of all employees with commission percentage null.

select e.first_name,j.job_title,h.start_date,h.end_date,e.commission_pct
from employees e
inner join
jobs j
on e.job_id=j.job_id
inner join 
job_history h
on e.job_id=h.job_id
where e.commission_pct is null;

--Display the departments into which no employee joined in last two years.

select department_id,(sysdate-hire_date)/365 as no_joined_last_two_years
from employees
where (sysdate-hire_date)/365>2;

--28.	Display the details of departments in which the max salary is greater than 10000 for employees who did a job in the past.

select j.employee_id,count(j.department_id),count(h.job_title)
from job_history j
inner join
jobs h
on j.job_id=h.job_id
group by  j.employee_id,h.max_salary
having h.max_salary>=10000
and count(j.department_id)>=1;

--29.	Display details of current job for employees who worked as IT Programmers in the past.
--just emplyee id=176 make SA_MAN and SA_REP but not employee does actually job and previous was it_prog

select  employee_id,job_id,count(department_id)
from job_history
group by employee_id,job_id;



--30.	Display the details of employees drawing the highest salary in the department.

select e.employee_id,e.first_name, e.job_id,e.salary,j.max_salary
from employees e
inner join 
jobs j
on e.job_id=j.job_id
where e.salary=j.max_salary;

--31.	Display the city of employee whose employee ID is 105.

select e.employee_id, l.city
from employees e
inner join
departments d
on e.department_id=d.department_id
inner join
locations l
on l.location_id=d.location_id
where employee_id=105;

--32.	Display third highest salary of all employees
select employee_id, salary
from employees
order by salary  desc;


