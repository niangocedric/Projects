
--1. Create the three following  tables:
--create salesperson table

create table Salesperson(
saleperson_id number(2),
name varchar2(20) not null,
age number(2),
salary number(6),

--constraints on salesperson table  

 constraint salesperson_salesperson_id_pr PRIMARY KEY(saleperson_id),
 constraint salesperson_salesperson_id_ck check (saleperson_id between 1 and 99),
 constraint salesperson_sales_age_ck check (age between 1 and 99),
 constraint salesperson_sales_salary_ck check (salary between 100 and 200000));
 
--insert into table salesperson

INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(1, 'Abe',61,140000);
INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(2,'Bob',	34,	44000);
INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(5	,'Chris',34	,40000);
INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(7,	'Dan',41,52000);
INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(8	,'Ken',57,115000);
INSERT INTO  Salesperson(saleperson_id,name,age,salary)
Values
(11	,'Joe',38,38000);


--create table customer

create table Customer(
customer_id number(2),
name varchar2(30) not null,
city  varchar2(30) not null,
Industry char(1) not null,
--constraints on customer table  

constraint customer_customer_id_pr PRIMARY KEY(customer_id),
constraint customer_customer_id_ck check (customer_id between 1 and 99),
constraint customer_industry_ck check ( industry in ('J','B')));

--insert values into table customer

INSERT INTO  Customer(customer_id,name,city,Industry)
Values
      (4,'Samsonic','pleasant','J');
      INSERT INTO  Customer(customer_id,name,city,Industry)
Values
      (6,'Panasung','oaktown','J');
      INSERT INTO  Customer(customer_id,name,city,Industry)
Values
      (7,'Samony','jackson','B');
      INSERT INTO  Customer(customer_id,name,city,Industry)
Values
      (9,'Orange','Jackson','B');


--create table Orders
 
 create table Orders(
order_id number(2),
order_date date ,
customer_id number(2),
saleperson_id number(2),
Amount number(5),   
--constraints on orders table    
constraint order_order_id_pr PRIMARY KEY(order_id),
constraint order_order_id_ck check (order_id between 1 and 99),
constraint customer_id_fk FOREIGN key(customer_id)  references Customer(customer_id),
constraint  salesperson_id_fk FOREIGN key(saleperson_id) references Salesperson(saleperson_id));

--insert into table orders
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values 
(10,'96-08-02',4,2,540);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(20	,'99-01-30',	4,	8,	1800);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(30	,'95-07-14',9,1,460);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(40	,'98-01-29',7,2,2400);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(50	,'98-02-03',	6,	7,	600);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(60	,'98-03-3',	6,	7	,720);
INSERT INTO  Orders(order_id,order_date,customer_id,saleperson_id,amount)
Values
(70	,'98-05-06',9,7,150);
 --2. . Write a SQL statement to insert rows into a table called highAchiever(Name, Age), where 
 -- salesperson must have a salary of 100,000 or greater to be included in the table.
create table highAchiever(
name varchar2(20) not null,
age number(2));

INSERT INTO  highAchiever(name, age)
VALUES ('Abe',61);
INSERT INTO  highAchiever(name, age)
VALUES ('Ken',57);



--a. The names of all salespeople that have an order with Samsonic.

SELECT s.name saleperson_name , c.name samsonic_order
FROM Salesperson s
   INNER JOIN
   Orders  o
   ON s.saleperson_id = o.saleperson_id
   INNER JOIN
   Customer  c
   ON o.customer_id = c.customer_id
   Where c.name='Samsonic';




--b. The names of all salespeople that do not have any order on the date 1/29/98

SELECT s.name saleperson_name, o.order_date exclude_date,c.name Customer_name
FROM Salesperson s
   INNER JOIN
   Orders  o
   ON s.saleperson_id = o.saleperson_id
   INNER JOIN
   Customer  c
   ON o.customer_id = c.customer_id
   Where o.order_date<>'98-01-29';

--c. The names of salespeople that have 2 or more orders. 

SELECT s.name, s.saleperson_id, s.age,s.salary,o.order_id
FROM Salesperson s
   INNER JOIN
   Orders  o
   ON s.saleperson_id = o.saleperson_id
   Where o.order_id>=2;


--d. The names of customer that have the name starts with "S". 


Select*
from Customer
WHERE  name LIKE 'S%';


Select*
from Customer
WHERE  name LIKE '_a%';

--e. The names of customers that have in the second letter "a" in their names.

Select*
from Customer
WHERE  name LIKE '_a%';
--f. Change the salary of sales person Dan to 150000.
UPDATE Salesperson
SET    salary = 150000
WHERE  name= 'Dan';

--verify your change
select*
from salesperson;
--g. Delete the order 70. 

DELETE FROM Orders
 WHERE  order_id =70;

--h. List  all orders with the following details:
--order_number, Amount, order_date, SalesPerson name, Customer name, 


SELECT o.order_id order_number  , o.Amount ,o.order_date, s.name Salesperson_name, c.name  Customer_name
FROM Orders o
   INNER JOIN
   Salesperson  s
   ON   o.saleperson_id=s.saleperson_id
   INNER JOIN
   Customer  c
   ON o.customer_id = c.customer_id;


