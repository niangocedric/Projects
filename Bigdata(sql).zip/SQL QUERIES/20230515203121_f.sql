

 
--Create the  following three  tables: 

 
--Create Students table: 

create table Students (
student_id number(10),
lastname varchar2(30) not null,
firstname varchar2(30) not null,
adress varchar2(50) not null,
city varchar2(20) not null,

--constraints on Students table  

 constraint student_student_id_pr PRIMARY KEY(student_id));
 
 --create Courses table : 
create table Courses(
course_id varchar2(4) not null,
coursename varchar2(30) not null,
credit_numbers number(1),

--constraints  in table courses 
 constraint courses_course_id_pr PRIMARY KEY(course_id),
 constraint courses_credit_numbers_ck check (credit_numbers between 1 and 8));
 
 -- create table  Results
create table Results(
student_id number(10),
course_id varchar2(4) not null,
session_  number(4),
marks    number(3),
creation_date date,

--constrainsts in table results

constraint Students_student_id_fk FOREIGN key(student_id)  references Students(student_id),
constraint Courses_course_id_fk FOREIGN key(course_id) references Courses(course_id),
constraint Results_session_ck check (session_ between 0101 and 1299),
constraint Results_marks_ck check (marks between 0 and 100));

--Display the structure of the three tables you just created. 
select* from  Students;
select* from  Courses;
select* from  Results;

--Question 2 :  (30 points) 


--insert into table Students

INSERT INTO  Students(student_id,lastname,firstname,adress,city)
Values 
(1111111111, 	'Smith ',	'Carolyn', 	'124 Rolling Hills St', 	'Fullerton' );

INSERT INTO  Students(student_id,lastname,firstname,adress,city)
Values 
(2222222222 ,'Diego ', 	'Maradona' ,	'100 Imperial  St', 'Brea' );

INSERT INTO  Students(student_id,lastname,firstname,adress,city)
Values 
(3333333333 ,	'Adam' , 	'Smith ',	'225 Bristol St' ,	'Irvine'  );

INSERT INTO  Students(student_id,lastname,firstname,adress,city)
Values 
(4444444444 	,'Crosby' ,	'Sidney' ,	'869 Coriander St', 	'Brea'   );

INSERT INTO  Students(student_id,lastname,firstname,adress,city)
Values 
(5555555555 	,'Ernest' ,	'Hemingway' ,	'125 Third Street', 	'Fullerton '   );

--insert into table Courses

INSERT INTO  Courses(course_id,coursename,credit_numbers)
Values 
('J01', 'Java ',4 );
INSERT INTO Courses(course_id,coursename,credit_numbers)
Values 
('B01' ,'Database',4 );

--insert into table  Results
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(1111111111, 'B01',	0110 	,55, '16-01-28' );
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(2222222222 	,'B01' ,	0110 ,	100 ,'16-01-28' );

INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 

(3333333333, 	'B01',0110 ,	80 ,'16-01-28' );
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(4444444444 	,'B01' ,0909 ,	55, '16-01-28');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(5555555555 	,'B01' ,	0909 ,	95, '16-01-28');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(1111111111 	,'J01' 	,0110 	,75 ,'16-01-10');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(2222222222 	,'J01' 	,0110 	,80 ,'16-01-10');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(3333333333 	,'J01' 	,0909 	,85 	,'16-01-10');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(4444444444 	,'J01' 	,0110 	,70 	,'16-01-10');
INSERT INTO Results(student_id,course_id,session_,marks, creation_date)
Values 
(5555555555 ,	'J01' ,	0110 ,	100 ,'16-01-10');


 
--1.	Display the students information ( studentid , lastname, firstname 
--, courseid, coursename and  marks). The results of this query must be sorted by coursename. 
 
SELECT s.student_id, s.lastname, s.firstname,r.course_id,c.coursename,r.marks
FROM Results r
   INNER JOIN
   Students  s
   ON r.student_id = s.student_id
   INNER JOIN
   Courses  c
   ON r.course_id = c.course_id;
   
--2.Display the students information  ( studentid , lastname,coursed, coursename) for students who have marks <  90.
SELECT s.student_id, s.lastname,r.course_id,c.coursename
FROM Results r
   INNER JOIN
   Students  s
   ON r.student_id = s.student_id
   INNER JOIN
   Courses  c
   ON r.course_id = c.course_id
   where marks <90;

--3.	Display the students information ( studentid, lastname, firstname)  for students  whose first name starts with an L or M  
select student_id, lastname, firstname
from Students
 WHERE  firstname LIKE 'L%'
 OR     firstname LIKE 'M%';
 
--4.	Update the  city field value in the Students table( City ="Torrance " for all students). 
 UPDATE Students
SET    city = 'Torrance';
--5.	Verify the update . 
select* from Students;
