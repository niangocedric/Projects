/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DaoImp;

import connection.conection;
import interfaceDao.GradingDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Grading;

/**
 *
 * @author cedric
 */
public class GradingDAOImplementation implements GradingDao {
   Connection connection = conection.getConnection();

    public GradingDAOImplementation() {
    }

    // Create a new Students
    public void create(Grading Gradin) {

        PreparedStatement preparedStatement;

        try {
            String createQuery = "INSERT INTO GRADING(sid,cid,marks1,marks2) VALUES(?,?,?,?)";
            preparedStatement = connection.prepareStatement(createQuery);

            preparedStatement.setInt(1, Gradin.getSid());
            preparedStatement.setInt(2, Gradin.getCid());
            preparedStatement.setInt(3, Gradin.getMarks1());
            preparedStatement.setInt(4, Gradin.getMarks2());
     
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Find by id
    @Override
    public Grading findById(int sid) {

        Grading gradings = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        try {
            String selectIdQuery = "SELECT * FROM GRADING where sid = ?";
            preparedStatement = connection.prepareStatement(selectIdQuery);
            preparedStatement.setInt(1, sid);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        try {
            resultSet.next();
            gradings = new Grading();
            gradings.setSid(resultSet.getInt("sid"));
            gradings.setCid(resultSet.getInt("cid"));
            gradings.setMarks1(resultSet.getInt("marks1"));
            gradings.setMarks2(resultSet.getInt("marks2"));
            

            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return gradings;
    }

    // find All people
    public List<Grading> findAll() {

        List<Grading> grading = new ArrayList<>();
        Grading gradings= null;
        ResultSet resultSet;
        PreparedStatement preparedStatement;

        try {
            String selectAllQuery = "SELECT * FROM GRADING ORDER BY SID";
            preparedStatement = connection.prepareStatement(selectAllQuery);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                gradings = new Grading();
                gradings.setSid(resultSet.getInt("sid"));
                gradings.setCid(resultSet.getInt("cid"));
                gradings.setMarks1(resultSet.getInt("marks1"));
                gradings.setMarks2(resultSet.getInt("marks2"));
               
                grading.add(gradings);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return grading;
    }

    // Update person's info
    public void update(Grading g) {

        PreparedStatement preparedStatement;

        try {
            String updateQuery = "UPDATE GRADING SET CID = ?,MARKS1 = ?,MARKS2=?  WHERE SID = ?";
            //System.out.println("Query = " + updateQuery);
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setInt(1, g.getCid());
            preparedStatement.setInt(2, g.getMarks1());
            preparedStatement.setInt(3, g.getMarks2());
            preparedStatement.setInt(4, g.getSid());
          
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete person
    public void delete(int sid) {

        PreparedStatement preparedStatement;

        try {
            String deleteQuery = "DELETE FROM GRADING WHERE SID =" + sid;
            preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
   
}
