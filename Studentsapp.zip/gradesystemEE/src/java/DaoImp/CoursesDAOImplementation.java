/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DaoImp;

import connection.conection;
import interfaceDao.CoursesDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Courses;

/**
 *
 * @author cedric
 */
public class CoursesDAOImplementation implements CoursesDao{
      Connection connection = conection.getConnection();

    public CoursesDAOImplementation() {
    }

    // Create a new Students
    public void create(Courses Course) {

        PreparedStatement preparedStatement;

        try {
            String createQuery = "INSERT INTO COURSES (cid, courseName,creditNumbers) VALUES(?,?,?)";
            preparedStatement = connection.prepareStatement(createQuery);

            preparedStatement.setInt(1, Course.getCid());
            preparedStatement.setString(2, Course.getCourseName());
            preparedStatement.setInt(3, Course.getCreditNumbers());
     
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Find by id
    @Override
    public Courses findById(int cid) {

        Courses courses = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        try {
            String selectIdQuery = "SELECT * FROM COURSES where cid = ?";
            preparedStatement = connection.prepareStatement(selectIdQuery);
            preparedStatement.setInt(1, cid);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        try {
            resultSet.next();
            courses = new Courses();
            courses.setCid(resultSet.getInt("cid"));
            courses.setCourseName(resultSet.getString("courseName"));
            courses.setCreditNumbers(resultSet.getInt("creditNumbers"));
            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return courses;
    }

    // find All people
    public List<Courses> findAll() {

        List<Courses> course = new ArrayList<>();
        Courses courses = null;
        ResultSet resultSet;
        PreparedStatement preparedStatement;

        try {
            String selectAllQuery = "SELECT * FROM COURSES ORDER BY CID";
            preparedStatement = connection.prepareStatement(selectAllQuery);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                courses = new Courses();
                courses.setCid(resultSet.getInt("cid"));
                courses.setCourseName(resultSet.getString("courseName"));
                courses.setCreditNumbers(resultSet.getInt("creditNumbers"));
               
                course.add(courses);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return course;
    }

    // Update person's info
    public void update(Courses c) {

        PreparedStatement preparedStatement;

        try {
            String updateQuery = "UPDATE COURSES SET courseName = ?,creditNumbers = ?  WHERE cid = ?";
            //System.out.println("Query = " + updateQuery);
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, c.getCourseName());
            preparedStatement.setInt(3, c.getCid());
            preparedStatement.setInt(2, c.getCreditNumbers());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete person
    public void delete(int cid) {

        PreparedStatement preparedStatement;

        try {
            String deleteQuery = "DELETE FROM COURSES WHERE CID =" + cid;
            preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
