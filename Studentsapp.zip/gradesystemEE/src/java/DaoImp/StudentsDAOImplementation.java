/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DaoImp;

import connection.conection;
import interfaceDao.StudentsDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Students;

/**
 *
 * @author cedric
 */
public class StudentsDAOImplementation implements StudentsDao {

    Connection connection = conection.getConnection();

    public StudentsDAOImplementation() {
    }

    // Create a new Students
    public void create(Students Student) {

        PreparedStatement preparedStatement;

        try {
            String createQuery = "INSERT INTO STUDENTS (sid, firstName,lastName, gender,CreateDate) VALUES(?,?,?,?,?)";
            preparedStatement = connection.prepareStatement(createQuery);

            preparedStatement.setInt(1, Student.getSid());
            preparedStatement.setString(2, Student.getFirstName());
            preparedStatement.setString(3, Student.getLastName());
            preparedStatement.setString(4, Student.getGender());
            preparedStatement.setString(5, Student.getCreateDate());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Find by id
    @Override
    public Students findById(int sid) {

        Students students = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        try {
            String selectIdQuery = "SELECT * FROM STUDENTS where sid = ?";
            preparedStatement = connection.prepareStatement(selectIdQuery);
            preparedStatement.setInt(1, sid);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        try {
            resultSet.next();
            students = new Students();
            students.setSid(resultSet.getInt("sid"));
            students.setFirstName(resultSet.getString("firstName"));
            students.setLastName(resultSet.getString("lastName"));
            students.setGender(resultSet.getString("gender"));
            students.setCreateDate(resultSet.getString("createDate"));
            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return students;
    }

    // find All people
    public List<Students> findAll() {

        List<Students> student = new ArrayList<>();
        Students students = null;
        ResultSet resultSet;
        PreparedStatement preparedStatement;

        try {
            String selectAllQuery = "SELECT * FROM STUDENTS ORDER BY SID";
            preparedStatement = connection.prepareStatement(selectAllQuery);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                students = new Students();
                students.setSid(resultSet.getInt("sid"));
                students.setFirstName(resultSet.getString("firstName"));
                students.setLastName(resultSet.getString("lastName"));
                students.setGender(resultSet.getString("gender"));
                students.setCreateDate(resultSet.getString("createDate"));

                student.add(students);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return student;
    }

    // Update person's info
    public void update(Students s) {

        PreparedStatement preparedStatement;

        try {
            String updateQuery = "UPDATE STUDENTS SET firstName = ?,lastName = ? ,gender = ?,CreateDate=? WHERE sid = ?";
            //System.out.println("Query = " + updateQuery);
            preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, s.getFirstName());
            preparedStatement.setInt(5, s.getSid());
            preparedStatement.setString(2, s.getLastName());
            preparedStatement.setString(3, s.getGender());
            preparedStatement.setString(4, s.getCreateDate());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete person
    public void delete(int sid) {

        PreparedStatement preparedStatement;

        try {
            String deleteQuery = "DELETE FROM STUDENTS WHERE SID =" + sid;
            preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
