/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author cedric
 */
public class Courses {
  private int cid; 
    private String courseName;
    private int creditNumbers;

    public Courses(int cid, String courseName, int creditNumbers) {
        this.cid = cid;
        this.courseName = courseName;
        this.creditNumbers = creditNumbers;
    }

    public Courses() {
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCreditNumbers() {
        return creditNumbers;
    }

    public void setCreditNumbers(int creditNumbers) {
        this.creditNumbers = creditNumbers;
    }

    @Override
    public String toString() {
        return "Courses{" + "cid=" + cid + ", courseName=" + courseName + ", creditNumbers=" + creditNumbers + '}';
    }
   
}
