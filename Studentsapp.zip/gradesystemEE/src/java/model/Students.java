/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author cedric
 */
public class Students {
    private int sid; 
    private String firstName;
    private String lastName;
    private String gender;
    private String createDate;

    public Students(int sid, String firstName, String lastName, String gender, String createDate) {
        this.sid = sid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.createDate = createDate;
    }

    public Students() {
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "Students{" + "sid=" + sid + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", createDate=" + createDate + '}';
    }

}
