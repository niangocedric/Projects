/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author cedric
 */
public class Grading {
   private int sid; 
    private int cid;
    private int marks1; 
    private int marks2;

    public Grading(int sid, int cid, int marks1, int marks2) {
        this.sid = sid;
        this.cid = cid;
        this.marks1 = marks1;
        this.marks2 = marks2;
    }

    public Grading() {
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getMarks1() {
        return marks1;
    }

    public void setMarks1(int marks1) {
        this.marks1 = marks1;
    }

    public int getMarks2() {
        return marks2;
    }

    public void setMarks2(int marks2) {
        this.marks2 = marks2;
    }

    @Override
    public String toString() {
        return "Grading{" + "sid=" + sid + ", cid=" + cid + ", marks1=" + marks1 + ", marks2=" + marks2 + '}';
    }
    
    
}
