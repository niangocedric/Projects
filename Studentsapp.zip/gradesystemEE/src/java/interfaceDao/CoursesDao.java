/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaceDao;

import java.util.List;
import model.Courses;

/**
 *
 * @author cedric
 */
public interface CoursesDao {
     void create(Courses c);
    
    void update(Courses c);
    
    void delete(int cid);

    List<Courses>findAll();

    Courses findById(int cid);
}
