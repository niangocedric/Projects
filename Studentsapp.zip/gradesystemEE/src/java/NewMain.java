
import DaoImp.CoursesDAOImplementation;
import interfaceDao.CoursesDao;
import java.util.List;
import model.Courses;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author cedric
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Grading grading = new Grading(4557,45,67,100);
          //Students student1 = new Students(4557,"cedric","Niango","M","23-07-09");
          Courses course1 = new Courses(200,"nn",3);
    
    //StudentsDao dao;
    CoursesDao dao;
   // GradingDao dao;
    //dao = new StudentsDAOImplementation();
     dao = new CoursesDAOImplementation();
   // dao = new GradingDAOImplementation();
     dao.create(course1);
     //dao.delete(4555);
      List<Courses> s1 = dao.findAll();
      for (Courses t : s1) {
                 //       System.out.println("Students List = " + s1);
                // Courses s=dao.findById(45);
                 System.out.println("Courses List = " + t);
    }
  
}
}

