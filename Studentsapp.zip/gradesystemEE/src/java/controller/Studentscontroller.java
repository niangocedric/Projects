/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DaoImp.StudentsDAOImplementation;
import interfaceDao.StudentsDao;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Students;

/**
 *
 * @author cedric
 */
@WebServlet(name = "Studentscontroller", urlPatterns = {"/Studentscontroller"})
public class Studentscontroller extends HttpServlet{
       
    StudentsDao dao;

    public void init() throws ServletException {
        
        dao = new StudentsDAOImplementation();
    }
    


    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         int sid = Integer.parseInt(request.getParameter("x"));
       String action = request.getParameter("act");
       if (action.equals("delete") ){
        dao.delete(sid);
         List<Students> listestudents = dao.findAll();
       
        request.setAttribute("listestudents", listestudents);
        
        getServletContext().getRequestDispatcher("/listestudents.jsp").
                forward(request, response);
       }
       else {
           
           Students stud = dao.findById(sid);
           request.setAttribute("student", stud);
           getServletContext().getRequestDispatcher("/student.jsp").
                forward(request, response);
       //  forward to jsp to sdisplay the date for the user
       //   the user changes data
       // Submit the data we changes from the from ( method post)
       // 
       
       
       
       }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         int sid = Integer.parseInt(request.getParameter("sid1"));
         String firstName = request.getParameter("firstname1");
         String lastName = request.getParameter("lastname1");
         String gender = request.getParameter("gender");
         String createDate = request.getParameter("createdate");
         
         
        Students student1 = new Students(sid,firstName,lastName,gender,createDate);
        Students stud =dao.findById(sid);
        if (stud.getSid()==0) {
        dao.create(student1);
        }
        else
        {
              dao.update(student1);
        }
        
        List<Students> listestudents = dao.findAll();
       
        request.setAttribute("listestudents", listestudents);
        
        getServletContext().getRequestDispatcher("/listestudents.jsp").
                forward(request, response);
        
        
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    } 
}


