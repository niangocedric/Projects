/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DaoImp.CoursesDAOImplementation;
import interfaceDao.CoursesDao;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Courses;

/**
 *
 * @author cedric
 */
@WebServlet(name = "Coursescontroller", urlPatterns = {"/Coursescontroller"})
public class Coursescontroller extends HttpServlet {
    CoursesDao dao;

    public void init() throws ServletException {
        
        dao = new CoursesDAOImplementation();
    }
    


    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         int cid = Integer.parseInt(request.getParameter("x"));
       String action = request.getParameter("act");
       if (action.equals("delete") ){
        dao.delete(cid);
         List<Courses> listecours = dao.findAll();
       
        request.setAttribute("listecours", listecours);
        
        getServletContext().getRequestDispatcher("/listecours.jsp").
                forward(request, response);
       }
       else {
           
           Courses cour = dao.findById(cid);
           request.setAttribute("student1", cour);
           getServletContext().getRequestDispatcher("/student1.jsp").
                forward(request, response);
       //  forward to jsp to sdisplay the date for the user
       //   the user changes data
       // Submit the data we changes from the from ( method post)
       // 
       
       
       
       }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         int cid = Integer.parseInt(request.getParameter("cid1"));
         String courseName = request.getParameter("coursename1");
         int creditNumbers = Integer.parseInt(request.getParameter("creditnumbers"));
        Courses courses1 = new Courses(cid,courseName,creditNumbers);
        Courses cour =dao.findById(cid);
        if (cour.getCid()==0) {
        dao.create(courses1);
        }
        else
        {
              dao.update(courses1);
        }
        
        List<Courses> listecours = dao.findAll();
       
        request.setAttribute("listecours", listecours);
        
        getServletContext().getRequestDispatcher("/listecours.jsp").
                forward(request, response);
        
        
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    } 
}
