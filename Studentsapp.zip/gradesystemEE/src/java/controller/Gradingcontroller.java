/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DaoImp.GradingDAOImplementation;
import interfaceDao.GradingDao;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Grading;
import model.Students;

/**
 *
 * @author cedric
 */
@WebServlet(name = "Gradingcontroller", urlPatterns = {"/Gradingcontroller"})
public class Gradingcontroller extends HttpServlet {
     GradingDao dao;

    public void init() throws ServletException {
        
        dao = new GradingDAOImplementation();
    }
    


    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("x"));
       String action = request.getParameter("act");
       if (action.equals("delete") ){
        dao.delete(id);
         List<Grading> listgrading = dao.findAll();
       
        request.setAttribute("listgrading", listgrading);
        
        getServletContext().getRequestDispatcher("/listgrading.jsp").
                forward(request, response);
       }
       else {
           
           Grading grad = dao.findById(id);
           request.setAttribute("student2", grad);
           getServletContext().getRequestDispatcher("/student2.jsp").
                forward(request, response);
       //  forward to jsp to sdisplay the date for the user
       //   the user changes data
       // Submit the data we changes from the from ( method post)
       // 
       
       
       
       }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         int sid = Integer.parseInt(request.getParameter("sid1"));
         int cid = Integer.parseInt(request.getParameter("cid"));
         int marks1 = Integer.parseInt(request.getParameter("marks1"));
         int marks2 = Integer.parseInt(request.getParameter("marks2"));
        
         
         
        Grading grading1 = new Grading(sid,cid,marks1,marks2);
        Grading grad =dao.findById(sid);
        if (grad.getCid()==0) {
        dao.create(grading1);
        }
        else
        {
              dao.update(grading1);
        }
        
        List<Grading> listgrading = dao.findAll();
       
        request.setAttribute("listgrading", listgrading);
        
        getServletContext().getRequestDispatcher("/listgrading.jsp").
                forward(request, response);
        
        
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    } 
}
